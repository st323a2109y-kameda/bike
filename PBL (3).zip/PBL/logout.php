<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no"> <!-- ズームを無効化 -->
    <title>ログアウト確認</title>
    <style>
        /* 全体のスタイル */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
            height: 100%;
            overflow: hidden; /* スクロールを無効化 */
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
        }

        .container {
            width: 300px;
            max-width: 90%;
            padding: 20px;
            text-align: center;
            box-sizing: border-box;
            background-color: #fff;
        }

        h2 {
            margin: 0;
            font-size: 20px;
        }

        p {
            margin: 20px 0;
            font-size: 20px;
        }

        .button-container {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 20px;
        }

        .button {
            width: 80px;
            padding: 10px;
            text-align: center;
            font-size: 16px;
            background-color: #d3d3d3;
            color: black;
            text-decoration: none;
            border: 1px solid gray;
            cursor: pointer;
        }

        .button:hover {
            background-color: #b0b0b0;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>ログアウト</h2>
    <p>本当に<br>ログアウトしますか？</p>
    <div class="button-container">
        <a href="index.php" class="button">YES</a>
        <a href="javascript:history.back();" class="button">NO</a>
    </div>
</div>

</body>
</html>
