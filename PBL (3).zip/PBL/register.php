<?php
require 'db.php';

$error_message = ""; // 初期化

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];
    $password = $_POST['password'];

    // バリデーション
    if (strlen($user_id) < 10) {
        $error_message = "個人IDは10桁以上で入力してください。";
    } elseif (strlen($password) < 8) {
        $error_message = "パスワードは8桁以上で入力してください。";
    } else {
        // パスワードをハッシュ化
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);

        // データベースに登録
        $stmt = $conn->prepare("INSERT INTO user (user_id, password) VALUES (?, ?)");
        $stmt->bind_param("ss", $user_id, $hashed_password);

        if ($stmt->execute()) {
            // 登録成功時にログイン画面にリダイレクト
            header("Location: success.php?success=1");
            exit;
        } else {
            $error_message = "この個人IDは既に使用されています。";
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>新規登録</title>
    <style>
        .error {
            color: red;
            margin-bottom: 10px;
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center; /* 水平方向に中央配置 */
            align-items: center;    /* 垂直方向に中央配置 */
            height: 100vh;          /* ビューポート全体の高さ */
            background-color: #f9f9f9;
        }
        form {
            width: 300px;
            padding: 20px;
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 24px;
        }
        .form-control {
            margin-bottom: 15px;
        }
        .form-control label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-control input {
            width: 100%;
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .button-container {
            display: flex;
            justify-content: space-between; /* ボタンを左右に配置 */
            margin-left: 25px;
            margin-top: 50px;
        }
        button {
            width: 48%; /* ボタンの幅を調整 */
            padding: 10px;
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .submit-button {
            background-color: #007BFF; /* 青色 */
            color: white;
        }
        .submit-button:hover {
            background-color: #0056b3; /* ホバー時の濃い青色 */
        }
        .back-button {
            background-color: #ccc; /* 灰色 */
            color: black;
        }
        .back-button:hover {
            background-color: #999; /* ホバー時の濃い灰色 */
        }
    </style>
</head>
<body>
    <form action="process_register.php" method="POST">
    <h1>新規登録</h1>
    <div class="form-control">
        <label for="user_id">個人ID (10桁以上)</label>
        <input type="text" id="user_id" name="user_id" required>
    </div>
    <div class="form-control">
        <label for="password">パスワード (8桁以上):</label>
        <input type="password" id="password" name="password" required>
    </div>
        <!-- エラーメッセージをボタンの上に表示 -->
        <?php if (!empty($error_message)): ?>
            <p class="error"><?php echo htmlspecialchars($error_message, ENT_QUOTES, 'UTF-8'); ?></p>
        <?php endif; ?>
    <div class="button-container">
        <button type="submit" class=submit-button>登録する</button>
        <button type="button" class="back-button" onclick="location.href='index.php'">戻る</button>
    </div>
    </form>
</body>
</html>
