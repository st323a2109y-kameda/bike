<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];  // 個人IDを取得
    $password = $_POST['password'];  // パスワードを取得

    // バリデーション: 個人IDが10桁以上であるかを確認
    if (strlen($user_id) < 10) {
        $error_message = "個人IDは10桁以上で入力してください。";
    } elseif (strlen($password) < 8) {
        $error_message = "パスワードは8桁以上で入力してください。";
    } else {
        // パスワードをハッシュ化
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);

        // データベースに登録
        $stmt = $conn->prepare("INSERT INTO users (user_id, password) VALUES (?, ?)");
        if ($stmt === false) {
            die("データベースクエリエラー: " . $conn->error);
        }
        $stmt->bind_param("ss", $user_id, $hashed_password);

        if ($stmt->execute()) {
            // 登録成功時にログイン画面にリダイレクト
            header("Location: success.php?success=1");
            exit;
        } else {
            $error_message = "この個人IDは既に使用されています。";
        }

        $stmt->close();
    }
}
?>

