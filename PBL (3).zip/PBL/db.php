<?php
$host = 'localhost';
$db = 'user';
$user = 'root';
$pass = ''; // MySQLのパスワード

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("データベース接続失敗: " . $conn->connect_error);
}
?>
