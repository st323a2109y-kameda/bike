<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];
    $password = $_POST['password'];

    // ユーザー情報を取得
    $stmt = $conn->prepare("SELECT password FROM users WHERE user_id = ?");
    $stmt->bind_param("s", $user_id);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($hashed_password);
        $stmt->fetch();

        // パスワード確認
        if (password_verify($password, $hashed_password)) {
            echo "ログイン成功！";
        } else {
            echo "パスワードが間違っています。";
        }
    } else {
        echo "個人IDが存在しません。";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理者ログイン</title>
    <style>
        /* 全体の基本スタイル */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        html, body {
            font-family: Arial, sans-serif;
            height: 100%;
            overflow: hidden; /* スクロールバーを非表示 */
        }
        .login-container {
            width: 100vw;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f5f5f5;
        }
        .login-box {
            text-align: center;
        }
        .login-box h2 {
            margin-bottom: 20px;
            font-size: 1.2em;
            font-weight: bold;
            color: #333;
        }
        .login-box label {
            display: block;
            text-align: left;
            font-weight: bold;
            margin-bottom: 5px;
            color: #333;
        }
        .login-box input[type="text"],
        .login-box input[type="password"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1em;
            box-sizing: border-box;
        }
        .login-box .error {
            color: #ff4d4d;
            font-size: 0.9em;
            margin-bottom: 15px;
        }
        .login-box button {
            width: 100%;
            padding: 12px;
            background-color: #4A90E2;
            color: #ffffff;
            border: none;
            border-radius: 5px;
            font-size: 1em;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .login-box button:hover {
            background-color: #357ABD;
        }

        /* 新規登録リンクにスタイルを追加 */
        .register-link {
            margin-top: 20px; /* 上部にスペースを追加 */
            display: inline-block;
            text-decoration: none;
            font-size: 18px;
        }
        .register-link:hover {
            text-decoration: underline;
        }
        .new-register {
            height: 16px; /* ログインフォームとリンクの間のスペース */
        }
        .error {
            color: red;
            margin-bottom: 10px;
            font-size: 14px;
        }
    </style>
</head>

<body>
<div class="login-container">
    <div class="login-box">
    <h2>管理者ログイン</h2>
    <form action="admin_main.php" method="post">
        <label for="user_id">個人ID</label>
        <input type="text" id="user_id" name="user_id" required>
        
        <label for="password">パスワード</label>
        <input type="password" id="password" name="password" required>

        <!-- エラーメッセージの表示 -->
        <?php if (!empty($error_message)): ?>
            <p class="error"><?php echo htmlspecialchars($error_message, ENT_QUOTES, 'UTF-8'); ?></p>
        <?php endif; ?>
        
        <button type="submit">ログイン</button>
    </form>
        <div class="new-register"></div>
            <a href="register.php">新規登録</a>
    </div>
</div>
</body>
</html>