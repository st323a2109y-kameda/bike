<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>利用履歴</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 0;
            padding: 0;
        }

        h1 {
            margin-top: 150px;
            font-size: 1.5em;
        }

        .table-container {
            width: 90%; /* スマホ対応で少し小さく */
            margin: 0 auto;
            max-height: 300px; /* 固定高さを設定 */
            overflow-y: auto; /* 縦スクロールを有効にする */
            padding: 10px;
            box-sizing: border-box;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid black;
            padding: 5px;
            text-align: left;
            font-size: 0.6em; /* スマホ向けに小さく */
        }

        th {
            background-color: #f2f2f2;
            position: sticky;
            top: 0;
            z-index: 1;
        }

        .back-button {
            display: inline-block;
            margin-top: 20px;
            aline: left;
            padding: 8px 16px;
            background-color: #f0f0f0;
            border: 1px solid #000;
            text-decoration: none;
            color: #000;
            font-size: 16px;
        }

        .back-button:hover {
            background-color: #e0e0e0;
        }

    </style>
</head>
<body>

<h1>利用履歴</h1>

<div class="table-container">
    <table>
        <tr>
            <th>name</th>
            <th>e-mail</th>
            <th>tell</th>
            <th>history</th>
            <th>VOC</th>
        </tr>
        <tr>
            <td>アンパンマン</td>
            <td>〇〇〇〇</td>
            <td>×××××</td>
            <td>2024.8.2<br>10:00-12:00</td>
            <td>小待っていいところですね</td>
        </tr>
        <!-- 追加行をここに書く -->
        <?php
        // 表の行を追加する場合は、以下のようにPHPで出力も可能です
        $data = [
            ['アンパンマン', '〇〇〇〇', '×××××', '2024.8.2<br>10:00-12:00', '小待っていいところですね'],
            ['ばいきんまん', '●●●●', '△△△△△', '2024.8.3<br>14:00-16:00', '楽しそうな場所です'],
            // 他のデータ行をここに追加
        ];

        foreach ($data as $row) {
            echo '<tr>';
            foreach ($row as $cell) {
                echo '<td>' . $cell . '</td>';
            }
            echo '</tr>';
        }
        ?>
    </table>
</div>

<a href="javascript:history.back();" class="back-button">戻る</a>

</body>
</html>