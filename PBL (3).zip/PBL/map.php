<?php
require 'db_bike.php';

// 自転車情報を取得
$stmt = $conn->prepare("SELECT id, name, status, latitude, longitude FROM bikes");
$stmt->execute();
$result = $stmt->get_result();
$bikes = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>貸出状況</title>

    <!-- Leaflet CSS -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />

    <!-- Leaflet JS -->
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 0 auto;
            padding: 0;
            max-width: 700px;
            font-size: 12px;
            overflow-x: hidden; /* 横スクロール無効化 */
        }

        h1 {
            margin: 50px 0;
            font-size: 30px;
        }

        #map {
            width: 90%;
            height: 400px;
            margin: 50px auto;
            border: 1px solid black;
        }

        #selected-bike {
            margin: 5px;
            font-size: 14px;
            font-weight: bold;
            color: darkgreen;
        }

        .bike-button {
            display: block;
            width: 90%;
            margin: 5px auto;
            padding: 10px;
            font-size: 14px;
            border: none;
            cursor: pointer;
            text-align: center;
            border-radius: 3px;
            color: white;
        }

        .bike-button.rental {
            background-color: red;
        }

        .bike-button.available {
            background-color: blue;
        }

        .bike-button:hover {
            opacity: 0.9;
        }

        #back-button {
            display: inline-block;
            margin: 30px auto;
            padding: 15px 25px;
            font-size: 12px;
            background-color: gray;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 3px;
            text-decoration: none;
            text-align: center;
        }

        #back-button:hover {
            opacity: 0.8;
        }
    </style>
</head>
<body>
    <h1>貸出状況</h1>
    <div id="map"></div>
    <div id="selected-bike">
        選択中の自転車: なし
    </div>

    <div>
        <?php foreach ($bikes as $bike): ?>
            <button
                class="bike-button <?= $bike['status'] === 'レンタル中' ? 'rental' : 'available' ?>"
                onclick="handleBikeClick('<?= htmlspecialchars($bike['name']) ?>', <?= $bike['latitude'] ?? 'null' ?>, <?= $bike['longitude'] ?? 'null' ?>, '<?= $bike['status'] ?>', this)">
                <?= htmlspecialchars($bike['name']) ?>（<?= htmlspecialchars($bike['status']) ?>）
            </button>
        <?php endforeach; ?>
    </div>

    <a href="admin_main.php" id="back-button">戻る</a>

    <script>
        // 地図の初期化
        const map = L.map('map').setView([36.7391, 137.1118], 15);

        // OpenStreetMapタイルを追加
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(map);

        // カスタムアイコン
        const rentalIcon = L.icon({
            iconUrl: 'https://cdn.jsdelivr.net/gh/pointhi/leaflet-color-markers@1.0/img/marker-icon-red.png',
            shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
        });

        const availableIcon = L.icon({
            iconUrl: 'https://cdn.jsdelivr.net/gh/pointhi/leaflet-color-markers@1.0/img/marker-icon-blue.png',
            shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
        });

        const gpsIcon = L.icon({
            iconUrl: 'https://cdn.jsdelivr.net/gh/pointhi/leaflet-color-markers@1.0/img/marker-icon-green.png',
            shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
        });

        // 現在のピンを追跡
        let currentMarkers = [];
        let gpsWatchId = null; // 位置情報のウォッチIDを保持
        let gpsMarker = null; // GPSマーカーを保持

        // 自転車の位置を管理
        function handleBikeClick(bikeName, lat, lng, status, button) {
            // 現在のマーカーをすべて削除
            currentMarkers.forEach(marker => map.removeLayer(marker));
            currentMarkers = [];
            if (gpsMarker) {
                map.removeLayer(gpsMarker);
                gpsMarker = null;
            }

            // 自転車「自転車01」を選択した場合、位置情報をリアルタイムで更新
            if (bikeName === '自転車01') {
                if (navigator.geolocation) {
                    // 既存のウォッチを解除
                    if (gpsWatchId !== null) {
                        navigator.geolocation.clearWatch(gpsWatchId);
                    }

                    // 新しいウォッチを開始
                    gpsWatchId = navigator.geolocation.watchPosition(
                        (position) => {
                            const { latitude, longitude } = position.coords;

                            // 既存のGPSマーカーを更新または新規作成
                            if (gpsMarker) {
                                gpsMarker.setLatLng([latitude, longitude]); // マーカー位置を更新
                            } else {
                                gpsMarker = L.marker([latitude, longitude], { icon: gpsIcon }).addTo(map);
                                gpsMarker.bindPopup(`<b>${bikeName}</b>`).openPopup();
                                currentMarkers.push(gpsMarker);
                            }

                            // マップを現在地にフォーカス
                            map.setView([latitude, longitude], 15);
                        },
                        (error) => {
                            alert('位置情報を取得できません: ' + error.message);
                        },
                        { enableHighAccuracy: true, maximumAge: 0, timeout: 10000 }
                    );
                } else {
                    alert('このブラウザはGeolocation APIに対応していません。');
                }
            } else {
                // 他の自転車の固定位置を表示
                if (lat && lng) {
                    const icon = status === 'レンタル中' ? rentalIcon : availableIcon;
                    const marker = L.marker([lat, lng], { icon }).addTo(map)
                        .bindPopup(`<b>${bikeName}</b>`).openPopup();
                    map.setView([lat, lng], 15);
                    currentMarkers.push(marker);
                }
            }

            // ボタンのスタイルを更新
            document.querySelectorAll('.bike-button').forEach(btn => btn.style.boxShadow = 'none');
            button.style.boxShadow = '0 0 10px 3px gold';

            // 選択中の自転車を更新
            document.getElementById('selected-bike').textContent = `選択中の自転車: ${bikeName}`;
        }
    </script>
</body>
</html>
