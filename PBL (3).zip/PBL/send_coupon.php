<?php
// 送信先メールアドレス（固定または変数に）
$toEmail = "cainaibei365@gmail.com"; // 必要に応じて変更

// ユニークなクーポンコードを生成
$couponCode = 'COUPON-' . strtoupper(bin2hex(random_bytes(4)));

// メールの件名
$subject = "【クーポン配布】自転車貸出しクーポン";

// メールの本文
$message = <<<EOT
こんにちは、

自転車のご利用ありがとうございます。
以下のクーポンコードを利用してお得に自転車をお楽しみください。

クーポンコード: $couponCode

このクーポンは一度限り有効です。
有効期限は7日間ですのでお早めにご利用ください。

何か質問がある場合はサポートまでお問い合わせください。

よろしくお願いいたします。

【自動送信メール】このメールには返信しないでください。
EOT;

// メールのヘッダー
$headers = [
    'From' => 'no-reply@bikeshare.com', // 差出人アドレス
    'Reply-To' => 'support@bikeshare.com', // サポート用メールアドレス
    'Content-Type' => 'text/plain; charset=UTF-8', // 文字コード設定
];

// メール送信
if (mail($toEmail, $subject, $message, $headers)) {
    echo "クーポンメールが送信されました！";
} else {
    echo "メール送信に失敗しました。";
}
