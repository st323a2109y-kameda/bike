<?php
// ユーザーIDのサンプル（本来はセッションやデータベースから取得することが多い）
$user_id = "1K34A678";
?>

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ユーザー画面</title>
    <style>
        /* 全体の基本スタイル */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        html, body {
            font-family: Arial, sans-serif;
            height: 100%;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #ffffff;
            overflow: hidden; 
        }
        .container {
            text-align: center;
            width: 100vw;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
        .user-id {
            font-size: 1.5em;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .button {
            display: inline-block;
            width: 250px;
            padding: 20px;
            margin: 10px 0;
            border: 2px solid #000;
            font-size: 1em;
            text-align: center;
            text-decoration: none;
            color: #000;
            background-color: transparent;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .button:hover {
            background-color: #f0f0f0;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="user-id">
        ユーザーID<br>
        <?php echo htmlspecialchars($user_id); ?>
    </div>
    
    <!-- ボタンをリンクに変更 -->
    <a href="map.php" class="button">Map</a>
    <a href="history.php" class="button">履歴一覧</a>
    <a href="logout.php" class="button">ログアウト</a>
</div>

</body>
</html>

