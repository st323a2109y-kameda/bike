<?php
$host = 'localhost';
$user = 'root'; // データベースのユーザー名
$password = ''; // データベースのパスワード
$database = 'bike_rental';

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("データベース接続に失敗しました: " . $conn->connect_error);
}
?>