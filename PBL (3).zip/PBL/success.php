<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>登録完了</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; margin-top: 50px; }
        .message { font-size: 24px; margin-bottom: 20px; }
        button { padding: 10px 20px; font-size: 16px; cursor: pointer; }
        a { text-decoration: none; color: white; }
        .back-button { background-color: #007BFF; color: white; border: none; border-radius: 5px; }
        .back-button:hover { background-color: #0056b3; }
    </style>
</head>
<body>
    <div class="message">登録が完了しました！</div>
    <button class="back-button" onclick="location.href='index.php'">ログインページに戻る</button>
</body>
</html>
